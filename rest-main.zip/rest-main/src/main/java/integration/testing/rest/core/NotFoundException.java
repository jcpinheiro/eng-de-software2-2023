package integration.testing.rest.core;

public class NotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
