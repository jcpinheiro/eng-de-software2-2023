package integration.testing.rest.userAPI;

public class UserNotFoundException extends RuntimeException {

}
