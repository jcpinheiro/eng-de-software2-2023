create table users (id integer not null, username varchar(255), password varchar(255), primary key (id));
create table recovery_log (log varchar(255));
