insert into users values (1,'admin','pass');
insert into users values (2,'john','pass');
